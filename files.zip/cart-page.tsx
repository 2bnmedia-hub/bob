'use client';

import Link from 'next/link';
import { useCart } from '@/context/CartContext';

export default function CartPage() {
  const { items, removeItem, updateQuantity, total, clearCart } = useCart();

  if (items.length === 0) {
    return (
      <main style={{ minHeight: '60vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 16, direction: 'rtl', padding: '40px var(--px)' }}>
        <div style={{ fontSize: 64 }}>🛒</div>
        <h1 style={{ fontSize: 24, fontWeight: 800, color: 'var(--brown)' }}>הסל שלך ריק</h1>
        <p style={{ color: 'var(--gray-600)', fontSize: 15 }}>הוסף מוצרים כדי להתחיל</p>
        <Link href="/" className="btn-secondary">חזור לקנייה</Link>
      </main>
    );
  }

  const shipping = total >= 400 ? 0 : 39;
  const finalTotal = total + shipping;

  return (
    <main style={{ direction: 'rtl', padding: '32px var(--px)', maxWidth: 'var(--max-w)', margin: '0 auto' }}>
      <h1 style={{ fontSize: 26, fontWeight: 800, color: 'var(--brown)', marginBottom: 8 }}>סל הקניות שלי</h1>
      <p style={{ color: 'var(--gray-400)', fontSize: 13, marginBottom: 28 }}>{items.reduce((s, i) => s + i.quantity, 0)} פריטים</p>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 340px', gap: 24, alignItems: 'start' }}>

        {/* ── ITEMS ── */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {items.map(item => (
            <div key={item.id} style={{
              display: 'grid',
              gridTemplateColumns: '90px 1fr auto',
              gap: 16,
              background: 'var(--white)',
              border: '1px solid var(--gray-200)',
              borderRadius: 'var(--radius-md)',
              padding: 16,
              alignItems: 'center',
            }}>
              {/* IMAGE */}
              <div style={{
                background: 'var(--gray-100)',
                borderRadius: 'var(--radius-sm)',
                height: 90,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: 32,
              }}>
                {item.image ? (
                  <img src={item.image} alt={item.name} style={{ width: '100%', height: '100%', objectFit: 'cover', borderRadius: 'var(--radius-sm)' }} />
                ) : '📦'}
              </div>

              {/* INFO */}
              <div>
                <div style={{ fontWeight: 700, fontSize: 15, color: 'var(--gray-800)', marginBottom: 4 }}>{item.name}</div>
                <div style={{ fontSize: 18, fontWeight: 800, color: 'var(--brown)' }}>₪{item.price.toFixed(2)}</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 10 }}>
                  <button
                    onClick={() => updateQuantity(item.id, item.quantity - 1)}
                    style={{ width: 30, height: 30, border: '1px solid var(--gray-200)', borderRadius: 6, background: 'var(--gray-50)', fontWeight: 700, fontSize: 16, cursor: 'pointer' }}
                  >−</button>
                  <span style={{ fontWeight: 700, fontSize: 15, minWidth: 24, textAlign: 'center' }}>{item.quantity}</span>
                  <button
                    onClick={() => updateQuantity(item.id, item.quantity + 1)}
                    style={{ width: 30, height: 30, border: '1px solid var(--gray-200)', borderRadius: 6, background: 'var(--gray-50)', fontWeight: 700, fontSize: 16, cursor: 'pointer' }}
                  >+</button>
                  <span style={{ color: 'var(--gray-400)', fontSize: 13, marginRight: 8 }}>
                    סה״כ: <strong style={{ color: 'var(--gray-800)' }}>₪{(item.price * item.quantity).toFixed(2)}</strong>
                  </span>
                </div>
              </div>

              {/* REMOVE */}
              <button
                onClick={() => removeItem(item.id)}
                style={{ background: 'none', border: 'none', color: 'var(--gray-400)', fontSize: 20, cursor: 'pointer', padding: 4 }}
                title="הסר מהסל"
              >✕</button>
            </div>
          ))}

          <button
            onClick={clearCart}
            style={{ alignSelf: 'flex-start', background: 'none', border: 'none', color: 'var(--gray-400)', fontSize: 13, cursor: 'pointer', textDecoration: 'underline', padding: 0 }}
          >
            נקה סל
          </button>
        </div>

        {/* ── SUMMARY ── */}
        <div style={{
          background: 'var(--cream)',
          border: '1px solid var(--cream-dark)',
          borderRadius: 'var(--radius-lg)',
          padding: 24,
          position: 'sticky',
          top: 140,
        }}>
          <h2 style={{ fontSize: 18, fontWeight: 800, color: 'var(--brown)', marginBottom: 20 }}>סיכום הזמנה</h2>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginBottom: 20 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14, color: 'var(--gray-600)' }}>
              <span>סכום ביניים</span>
              <span>₪{total.toFixed(2)}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14, color: 'var(--gray-600)' }}>
              <span>משלוח</span>
              <span style={{ color: shipping === 0 ? 'green' : 'inherit' }}>
                {shipping === 0 ? 'חינם 🎉' : `₪${shipping}`}
              </span>
            </div>
            {shipping > 0 && (
              <div style={{ background: 'var(--gold-light)', borderRadius: 6, padding: '8px 12px', fontSize: 12, color: 'var(--brown)' }}>
                🚚 הוסף עוד ₪{(400 - total).toFixed(2)} לקבלת משלוח חינם
              </div>
            )}
            <div style={{ height: 1, background: 'var(--cream-dark)', margin: '4px 0' }} />
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 18, fontWeight: 800, color: 'var(--brown)' }}>
              <span>סה״כ</span>
              <span>₪{finalTotal.toFixed(2)}</span>
            </div>
            <div style={{ fontSize: 11, color: 'var(--gray-400)', textAlign: 'center' }}>כולל מע״מ</div>
          </div>

          {/* COUPON */}
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--brown)', marginBottom: 6 }}>קוד קופון</div>
            <div style={{ display: 'flex' }}>
              <input
                type="text"
                placeholder="הכנס קוד..."
                style={{
                  flex: 1,
                  border: '1px solid var(--gray-200)',
                  borderRadius: '6px 0 0 6px',
                  padding: '8px 12px',
                  fontSize: 13,
                  fontFamily: 'var(--font)',
                  direction: 'rtl',
                  outline: 'none',
                }}
              />
              <button style={{
                background: 'var(--brown)',
                color: 'var(--gold)',
                fontWeight: 700,
                fontSize: 13,
                padding: '8px 14px',
                borderRadius: '0 6px 6px 0',
                border: 'none',
                cursor: 'pointer',
                fontFamily: 'var(--font)',
              }}>
                החל
              </button>
            </div>
          </div>

          <button className="btn-primary" style={{ width: '100%', justifyContent: 'center', fontSize: 16, padding: '14px 0' }}>
            לתשלום ← 
          </button>

          <div style={{ display: 'flex', justifyContent: 'center', gap: 16, marginTop: 14 }}>
            <span style={{ fontSize: 11, color: 'var(--gray-400)' }}>🔒 תשלום מאובטח</span>
            <span style={{ fontSize: 11, color: 'var(--gray-400)' }}>🔄 החזרה בתוך 30 יום</span>
          </div>

          <div style={{ marginTop: 16, textAlign: 'center' }}>
            <Link href="/" style={{ fontSize: 13, color: 'var(--brown)', textDecoration: 'underline' }}>
              ← המשך בקנייה
            </Link>
          </div>
        </div>
      </div>
    </main>
  );
}
