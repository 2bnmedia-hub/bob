'use client';

import Link from 'next/link';
import { useState } from 'react';
import { useCart } from '@/context/CartContext';

/* ─── PLACEHOLDER DATA ─── */
const HERO_SLIDES = [
  { title: 'חסכו עד ₪300', sub: 'על מוצרי בנייה נבחרים מהמותגים המובילים', btn: 'לקנייה עכשיו', bg: '#f0ede8', badge: 'מבצע מיוחד' },
  { title: 'כלי עבודה מקצועיים', sub: 'מבחר ענק של כלים ממותגים מובילים', btn: 'גלו עכשיו', bg: '#e8f0f5', badge: 'חדש' },
  { title: 'צבע לכל פרויקט', sub: 'גוונים ללא גבול, איכות ללא פשרות', btn: 'בחרו צבע', bg: '#f5ece8', badge: 'קיץ 2025' },
];

const PROMO_PRODUCTS = [
  { id: 'p1', name: 'ערכת כלים מקצועית 18 חלקים', price: 280, was: 350, rating: 4.5, reviews: 1234 },
  { id: 'p2', name: 'מקדחה נטענת 18V', price: 160, was: 200, rating: 4.0, reviews: 567 },
  { id: 'p3', name: 'מסור עגול מקצועי', price: 380, was: 450, rating: 5.0, reviews: 89 },
  { id: 'p4', name: 'גנרטור 2000W', price: 420, was: 520, rating: 4.0, reviews: 321 },
];

const FEATURED_PRODUCTS = [
  { id: 'f1', name: 'מכונת גרס ענפים 2400W', price: 749, was: 850, rating: 4.5, reviews: 1200 },
  { id: 'f2', name: 'ריתוך MIG 160A', price: 499, was: 750, rating: 4.0, reviews: 500 },
  { id: 'f3', name: 'גז דגם 4 להבות', price: 300, was: 430, rating: 5.0, reviews: 200 },
  { id: 'f4', name: 'מסגרת אלומיניום 3×3', price: 389, was: 580, rating: 4.0, reviews: 400 },
  { id: 'f5', name: 'מרסס חשמלי 650W', price: 259, was: 350, rating: 4.5, reviews: 800 },
  { id: 'f6', name: 'מוט בטון 6מ׳ Ø10', price: 120, was: 140, rating: 4.0, reviews: 3400 },
];

const CATEGORIES = [
  { name: 'מבצע', icon: '🏷️', red: true, href: '/sales' },
  { name: 'בניין ושיפוץ', icon: '🧱', href: '/category/building' },
  { name: 'כלי עבודה', icon: '🔧', href: '/category/tools' },
  { name: 'חשמל ותאורה', icon: '💡', href: '/category/electric' },
  { name: 'צבע וגימור', icon: '🎨', href: '/category/paint' },
  { name: 'אינסטלציה', icon: '🚿', href: '/category/plumbing' },
  { name: 'גינה וחוץ', icon: '🌿', href: '/category/garden' },
  { name: 'דלתות וחלונות', icon: '🚪', href: '/category/doors' },
  { name: 'ריצוף', icon: '⬛', href: '/category/flooring' },
];

const TOP_CATEGORIES_TABS = ['הכל', 'מכסחות', 'גריל ובישול', 'כלי חשמל', 'גינון'];

const DEALS_CAROUSEL = [
  { title: 'קנה 2 חסוך ₪15', sub: 'על צבעים נבחרים', badge: '★', wide: true },
  { title: 'חסוך ₪4', sub: 'על חומרי איטום' },
  { title: 'חסוך ₪40', sub: 'על סולמות נבחרים', badge: 'Ace Rewards' },
  { title: 'חסוך ₪20', sub: 'על כלי ריתוך' },
];

const BRANDS = [
  'DeWalt', 'Milwaukee', 'Bosch', 'Makita', 'Stanley', 'Hilti', 'Festool',
  'Stihl', 'Weber', 'Traeger', 'Bosh מים', 'Benjamin Moore', 'Scotts', 'Valspar',
];

const EDITORIAL_TABS = [
  { label: 'טיפ שיפוץ', title: 'כיצד לסיים קירות בטון בקלות', body: 'מדריך מקיף לעבודה עם חומרי גימור, כולל ביטחון ובטיחות.' },
  { label: 'גינון', title: 'גינת קיץ — 5 טיפים מהאחראים', body: 'מיתוג הגינה שלכם לאורך כל הקיץ עם הצמחים והכלים הנכונים.' },
  { label: 'ארגון', title: 'ארגון מחסן — מדריך מלא', body: 'כל מה שצריך לדעת כדי לשמור על מחסן נקי ומאורגן לאורך זמן.' },
  { label: 'צביעה', title: 'בחירת גוון צבע — מדריך עיצובי', body: 'איך לבחור את הצבע שיוסיף חיים לכל חדר, שלב אחר שלב.' },
];

/* ─── STARS ─── */
function Stars({ rating }: { rating: number }) {
  return (
    <div className="stars">
      {'★★★★★'.split('').map((_, i) => (
        <span key={i} style={{ opacity: i < Math.round(rating) ? 1 : 0.25 }}>★</span>
      ))}
    </div>
  );
}

/* ─── PRODUCT CARD ─── */
function ProductCard({ product, badge }: { product: typeof PROMO_PRODUCTS[0]; badge?: string }) {
  const { addItem } = useCart();
  const [added, setAdded] = useState(false);

  function handleAdd() {
    addItem({ id: product.id, name: product.name, price: product.price, quantity: 1 });
    setAdded(true);
    setTimeout(() => setAdded(false), 1400);
  }

  return (
    <div style={{
      border: '1px solid var(--gray-200)',
      borderRadius: 'var(--radius-md)',
      padding: 14,
      background: 'var(--white)',
      display: 'flex',
      flexDirection: 'column',
      gap: 8,
      transition: 'box-shadow 0.18s, transform 0.18s',
    }}
      onMouseEnter={e => { e.currentTarget.style.boxShadow = 'var(--shadow-md)'; e.currentTarget.style.transform = 'translateY(-2px)'; }}
      onMouseLeave={e => { e.currentTarget.style.boxShadow = 'none'; e.currentTarget.style.transform = 'translateY(0)'; }}
    >
      {/* IMAGE */}
      <div style={{ position: 'relative' }}>
        {badge && (
          <span className={`badge badge-dark`} style={{ position: 'absolute', top: 6, right: 6 }}>{badge}</span>
        )}
        <div style={{
          background: 'var(--gray-100)',
          borderRadius: 'var(--radius-sm)',
          height: 140,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontSize: 48,
          color: 'var(--gray-400)',
        }}>📦</div>
      </div>

      {/* NAME */}
      <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--gray-800)', lineHeight: 1.4, minHeight: 36 }}>
        {product.name}
      </div>

      {/* STARS */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <Stars rating={product.rating} />
        <span style={{ fontSize: 11, color: 'var(--gray-400)' }}>{product.reviews.toLocaleString()}</span>
      </div>

      {/* PRICE */}
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
        <span className="price-now">₪{product.price}</span>
        {product.was && <span className="price-was">₪{product.was}</span>}
      </div>

      {/* ADD */}
      <button className="add-to-cart-btn" onClick={handleAdd}
        style={{ background: added ? 'var(--green, #2e7d32)' : undefined, color: added ? '#fff' : undefined, borderColor: added ? 'var(--green, #2e7d32)' : undefined }}
      >
        {added ? '✓ נוסף לסל' : 'הוסף לסל'}
      </button>
    </div>
  );
}

/* ─── SECTION WRAPPER ─── */
function Section({ children, bg, py = 40 }: { children: React.ReactNode; bg?: string; py?: number }) {
  return (
    <section style={{ background: bg || 'var(--white)', padding: `${py}px 0` }}>
      <div className="container">{children}</div>
    </section>
  );
}

/* ────────────────────────────────────────────── */
export default function HomePage() {
  const [heroIdx, setHeroIdx] = useState(0);
  const [editTab, setEditTab] = useState(0);
  const [catTab, setCatTab] = useState(0);
  const hero = HERO_SLIDES[heroIdx];

  return (
    <main style={{ direction: 'rtl' }}>

      {/* ══════════ HERO ══════════ */}
      <section style={{ background: 'var(--cream)', padding: '16px 0 0' }}>
        <div className="container">
          <div style={{ display: 'grid', gridTemplateColumns: '3fr 1fr', gap: 12 }}>

            {/* MAIN SLIDE */}
            <div style={{
              background: hero.bg,
              borderRadius: 'var(--radius-lg)',
              padding: '40px 36px',
              minHeight: 280,
              position: 'relative',
              overflow: 'hidden',
            }}>
              <span className="badge badge-red" style={{ marginBottom: 12, display: 'inline-block' }}>{hero.badge}</span>
              <h1 style={{ fontSize: 'clamp(32px, 5vw, 52px)', fontWeight: 900, color: 'var(--brown-dark)', lineHeight: 1.1, marginBottom: 12 }}>
                {hero.title}
              </h1>
              <p style={{ fontSize: 15, color: 'var(--gray-600)', maxWidth: 340, marginBottom: 24, lineHeight: 1.6 }}>
                {hero.sub}
              </p>
              <button className="btn-secondary">{hero.btn}</button>

              {/* PLACEHOLDER IMAGE */}
              <div style={{
                position: 'absolute', left: 40, top: '50%', transform: 'translateY(-50%)',
                width: 220, height: 180,
                background: 'rgba(0,0,0,0.06)',
                borderRadius: 12,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 60,
              }}>📸</div>

              {/* DOTS */}
              <div style={{ position: 'absolute', bottom: 16, right: 36, display: 'flex', gap: 8 }}>
                {HERO_SLIDES.map((_, i) => (
                  <button key={i} onClick={() => setHeroIdx(i)} style={{
                    width: i === heroIdx ? 24 : 8, height: 8,
                    borderRadius: 4,
                    background: i === heroIdx ? 'var(--brown)' : 'var(--gray-400)',
                    border: 'none', cursor: 'pointer', transition: 'width 0.2s',
                  }} />
                ))}
              </div>

              {/* ARROWS */}
              <button onClick={() => setHeroIdx((heroIdx - 1 + HERO_SLIDES.length) % HERO_SLIDES.length)}
                style={{ position: 'absolute', top: '50%', right: 12, transform: 'translateY(-50%)', background: 'rgba(255,255,255,0.8)', border: 'none', borderRadius: '50%', width: 36, height: 36, cursor: 'pointer', fontSize: 16 }}>›</button>
              <button onClick={() => setHeroIdx((heroIdx + 1) % HERO_SLIDES.length)}
                style={{ position: 'absolute', top: '50%', left: 12, transform: 'translateY(-50%)', background: 'rgba(255,255,255,0.8)', border: 'none', borderRadius: '50%', width: 36, height: 36, cursor: 'pointer', fontSize: 16 }}>‹</button>
            </div>

            {/* SIDE BANNERS */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <div style={{ background: 'var(--cream-dark)', borderRadius: 'var(--radius-md)', padding: 20, flex: 1 }}>
                <div style={{ fontSize: 10, color: 'var(--gray-400)', marginBottom: 4 }}>ממומן</div>
                <div style={{ fontSize: 15, fontWeight: 700, color: 'var(--brown)', marginBottom: 8, lineHeight: 1.4 }}>קל להרכיב,<br/>קל לגמור</div>
                <Link href="#" style={{ color: 'var(--red)', fontSize: 12, fontWeight: 700 }}>לקנייה עכשיו ←</Link>
              </div>
              <div style={{ background: 'var(--brown)', borderRadius: 'var(--radius-md)', padding: 20, flex: 1 }}>
                <div style={{ fontSize: 14, fontWeight: 800, color: 'var(--gold)', marginBottom: 6 }}>מבצע מותג הבית</div>
                <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.75)', marginBottom: 10 }}>מוצרים איכותיים במחיר מיוחד</div>
                <Link href="#" style={{ color: 'var(--gold-light)', fontSize: 12, fontWeight: 700 }}>גלה עוד ←</Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ══════════ BRAND PROMO + PRODUCTS ══════════ */}
      <Section bg="var(--cream)" py={24}>
        <div style={{ display: 'grid', gridTemplateColumns: '280px 1fr', gap: 16 }}>
          {/* BANNER */}
          <div style={{ background: 'var(--red)', borderRadius: 'var(--radius-lg)', padding: 28, color: '#fff', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
            <div>
              <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 1, opacity: 0.8, marginBottom: 6 }}>מותג מוביל</div>
              <h2 style={{ fontSize: 26, fontWeight: 900, lineHeight: 1.2, marginBottom: 8 }}>קולקציית<br/>הקיץ 2025</h2>
              <p style={{ fontSize: 13, opacity: 0.85, marginBottom: 20 }}>מוצרים נבחרים במחיר מיוחד</p>
            </div>
            <button style={{ background: '#fff', color: 'var(--red)', border: 'none', padding: '9px 20px', fontWeight: 700, fontSize: 13, borderRadius: 6, cursor: 'pointer', fontFamily: 'var(--font)' }}>
              לקנייה עכשיו
            </button>
          </div>

          {/* PRODUCTS */}
          <div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
              {PROMO_PRODUCTS.map(p => (
                <ProductCard key={p.id} product={p} badge="ONLINE DEAL" />
              ))}
            </div>
            <div style={{ display: 'flex', justifyContent: 'center', gap: 8, marginTop: 12 }}>
              {[0,1,2,3].map(i => (
                <div key={i} style={{ width: i === 0 ? 24 : 8, height: 8, borderRadius: 4, background: i === 0 ? 'var(--gold)' : 'var(--gray-200)', transition: 'width 0.2s' }} />
              ))}
            </div>
          </div>
        </div>
      </Section>

      {/* ══════════ PRODUCTS + SAVE MORE ══════════ */}
      <Section py={32}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 280px', gap: 16 }}>
          <div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
              {PROMO_PRODUCTS.map(p => (
                <ProductCard key={`bms-${p.id}`} product={{ ...p, id: `bms-${p.id}` }} badge="קנה יותר חסוך יותר" />
              ))}
            </div>
          </div>
          <div style={{ border: '2px solid var(--red)', borderRadius: 'var(--radius-lg)', padding: 24, textAlign: 'center' }}>
            <h2 style={{ fontSize: 20, fontWeight: 900, color: 'var(--gray-800)', marginBottom: 8 }}>קנה יותר,<br/>חסוך יותר</h2>
            <p style={{ fontSize: 12, color: 'var(--gray-600)', marginBottom: 16 }}>חסוך על מוצרי בנייה נבחרים</p>
            <div style={{ display: 'flex', gap: 8, justifyContent: 'center', marginBottom: 16 }}>
              {[['₪250','₪50'],['₪350+','₪100']].map(([spend,save],i) => (
                <div key={i} style={{ background: 'var(--red)', color: '#fff', borderRadius: 6, padding: '10px 14px', fontSize: 11, fontWeight: 700, lineHeight: 1.5 }}>
                  הוצא<br/>{spend}<br/><span style={{ fontSize: 10, opacity: 0.85 }}>חסוך {save}</span>
                </div>
              ))}
            </div>
            <button className="btn-secondary" style={{ width: '100%', justifyContent: 'center', fontSize: 13 }}>לקנייה עכשיו</button>
          </div>
        </div>
      </Section>

      {/* ══════════ FULL PROMO BANNER ══════════ */}
      <Section bg="var(--cream)" py={0}>
        <div style={{ background: 'var(--red)', borderRadius: 'var(--radius-lg)', padding: '20px 32px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', margin: '0 0 0 0' }}>
          <h2 style={{ fontSize: 20, fontWeight: 700, color: '#fff' }}>🎁 מצא את המתנה המושלמת לכל פרויקט</h2>
          <button className="btn-primary">לקנייה עכשיו</button>
        </div>
      </Section>

      {/* ══════════ BOB GOLD DAYS ══════════ */}
      <Section bg="var(--cream)" py={16}>
        <div style={{ background: 'var(--cream-dark)', borderRadius: 'var(--radius-lg)', padding: '24px 32px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <div style={{ fontSize: 11, color: 'var(--gray-400)', marginBottom: 4 }}>מבצע מיוחד מגיע</div>
            <div style={{ fontSize: 26, fontWeight: 900, color: 'var(--brown)' }}>ימי הזהב של BOB</div>
            <div style={{ fontSize: 13, color: 'var(--gray-600)', marginBottom: 12 }}>מבצעים שלא תרצו לפספס</div>
            <button style={{ background: 'var(--red)', color: '#fff', border: 'none', padding: '9px 20px', fontWeight: 700, fontSize: 13, borderRadius: 6, cursor: 'pointer', fontFamily: 'var(--font)' }}>
              לקנייה מוקדמת
            </button>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            {['📦','🔧','🎨','💡'].map((icon,i) => (
              <div key={i} style={{ width: 64, height: 64, background: i === 1 ? 'var(--brown)' : 'var(--gray-200)', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 24, color: i === 1 ? 'var(--gold)' : undefined }}>
                {i === 1 ? <span style={{ fontSize: 12, fontWeight: 700, color: 'var(--gold)', textAlign: 'center', lineHeight: 1.3 }}>23–26<br/>יוני</span> : icon}
              </div>
            ))}
          </div>
        </div>
      </Section>

      {/* ══════════ TOP DEALS ══════════ */}
      <Section py={40}>
        <h2 className="section-title">בדקו את העסקאות הטובות ביותר</h2>
        <div style={{ background: 'var(--red)', borderRadius: 'var(--radius-md)', padding: '16px 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
          <div>
            <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.75)', marginBottom: 2 }}>מבצע</div>
            <h3 style={{ fontSize: 18, fontWeight: 800, color: '#fff' }}>₪49 בלבד — ערכת כלים נבחרת כולל נרתיק</h3>
          </div>
          <button className="btn-primary">לקנייה עכשיו</button>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr', gap: 12 }}>
          <div style={{ background: 'var(--brown-dark)', borderRadius: 'var(--radius-md)', padding: 28 }}>
            <div style={{ fontSize: 13, color: 'var(--gold-light)', marginBottom: 4 }}>חסוך עד</div>
            <div style={{ fontSize: 52, fontWeight: 900, color: 'var(--red)', lineHeight: 1 }}>₪300</div>
            <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.7)', margin: '8px 0 16px' }}>על ציוד בנייה נבחר</div>
            <button className="btn-primary" style={{ fontSize: 13, padding: '9px 20px' }}>לקנייה עכשיו</button>
          </div>
          <div style={{ background: 'var(--gray-100)', borderRadius: 'var(--radius-md)', padding: 24 }}>
            <div style={{ fontSize: 12, color: 'var(--gray-600)', marginBottom: 6 }}>חסוך</div>
            <div style={{ fontSize: 38, fontWeight: 900, color: 'var(--red)', lineHeight: 1 }}>₪4</div>
            <div style={{ fontSize: 12, color: 'var(--gray-600)', marginTop: 6 }}>על חומרי איטום נבחרים</div>
          </div>
          <div style={{ background: 'var(--gray-100)', borderRadius: 'var(--radius-md)', padding: 24 }}>
            <div style={{ fontSize: 12, color: 'var(--gray-600)', marginBottom: 6 }}>חסוך</div>
            <div style={{ fontSize: 38, fontWeight: 900, color: 'var(--red)', lineHeight: 1 }}>₪40</div>
            <div style={{ fontSize: 12, color: 'var(--gray-600)', marginTop: 6 }}>על סולמות נבחרים</div>
          </div>
        </div>
      </Section>

      {/* ══════════ SHOP BY CATEGORY ══════════ */}
      <Section bg="var(--cream)" py={40}>
        <h2 className="section-title">קנייה לפי קטגוריה</h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(9, 1fr)', gap: 12 }}>
          {CATEGORIES.map(cat => (
            <Link key={cat.href} href={cat.href} style={{ textAlign: 'center', textDecoration: 'none' }}>
              <div style={{
                width: 64, height: 64,
                borderRadius: '50%',
                background: cat.red ? 'var(--red)' : 'var(--white)',
                border: cat.red ? 'none' : '1.5px solid var(--gray-200)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: cat.red ? 13 : 26,
                fontWeight: cat.red ? 800 : undefined,
                color: cat.red ? '#fff' : undefined,
                margin: '0 auto 10px',
                transition: 'box-shadow 0.15s, transform 0.15s',
                boxShadow: 'var(--shadow-sm)',
              }}>
                {cat.red ? 'מבצע' : cat.icon}
              </div>
              <div style={{ fontSize: 12, color: 'var(--gray-600)', fontWeight: 600, lineHeight: 1.3 }}>{cat.name}</div>
            </Link>
          ))}
        </div>
      </Section>

      {/* ══════════ BIG SAVINGS ══════════ */}
      <Section py={40}>
        <h2 className="section-title">חסכונות גדולים לכל פרויקט</h2>
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 16, marginBottom: 16 }}>
          <div style={{ background: 'var(--brown-dark)', borderRadius: 'var(--radius-lg)', padding: 36, minHeight: 220, display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
            <div style={{ fontSize: 13, color: 'var(--gold-light)', marginBottom: 6 }}>חסוך עד</div>
            <div style={{ fontSize: 64, fontWeight: 900, color: 'var(--red)', lineHeight: 1 }}>₪200</div>
            <div style={{ fontSize: 14, color: 'rgba(255,255,255,0.75)', margin: '8px 0 20px' }}>על מוצר מוביל נבחר</div>
            <button className="btn-primary" style={{ alignSelf: 'flex-start' }}>לקנייה עכשיו</button>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {[['₪500','מוצר א׳'],['₪100','מוצר ב׳']].map(([n, sub]) => (
              <div key={sub} style={{ background: 'var(--gray-100)', borderRadius: 'var(--radius-md)', padding: 24, flex: 1 }}>
                <div style={{ fontSize: 12, color: 'var(--gray-600)' }}>חסוך עד</div>
                <div style={{ fontSize: 36, fontWeight: 900, color: 'var(--red)', lineHeight: 1 }}>{n}</div>
                <div style={{ fontSize: 12, color: 'var(--gray-600)', marginTop: 4 }}>על {sub}</div>
              </div>
            ))}
          </div>
        </div>

        {/* 3-COL SMALLER */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
          {[['₪200','מכסחות Toro'],['₪50','מכסחות Stihl'],['₪200','מוצרי EGO']].map(([n,sub]) => (
            <div key={sub} style={{ border: '1px solid var(--gray-200)', borderRadius: 'var(--radius-md)', padding: 20 }}>
              <div style={{ fontSize: 12, color: 'var(--gray-400)' }}>חסוך עד</div>
              <div style={{ fontSize: 28, fontWeight: 900, color: 'var(--red)', lineHeight: 1 }}>{n}</div>
              <div style={{ fontSize: 12, color: 'var(--gray-600)', margin: '4px 0 12px' }}>על {sub}</div>
              <span className="badge badge-dark">Online Deal</span>
            </div>
          ))}
        </div>
      </Section>

      {/* ══════════ SHOP TOP CATEGORIES ══════════ */}
      <Section bg="var(--cream)" py={40}>
        <h2 className="section-title">קטגוריות מובילות</h2>
        <div style={{ display: 'flex', gap: 4, marginBottom: 16 }}>
          {TOP_CATEGORIES_TABS.map((tab, i) => (
            <button key={tab} onClick={() => setCatTab(i)} style={{
              padding: '7px 16px',
              fontSize: 13,
              fontWeight: 600,
              border: 'none',
              borderRadius: 0,
              cursor: 'pointer',
              fontFamily: 'var(--font)',
              background: i === catTab ? 'var(--brown)' : 'var(--cream-dark)',
              color: i === catTab ? 'var(--gold)' : 'var(--gray-600)',
              borderBottom: i === catTab ? '2px solid var(--gold)' : '2px solid transparent',
            }}>{tab}</button>
          ))}
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 12 }}>
          {FEATURED_PRODUCTS.map(p => (
            <ProductCard key={`feat-${p.id}`} product={p} badge="SALE" />
          ))}
        </div>
      </Section>

      {/* ══════════ TOP DEALS CAROUSEL ══════════ */}
      <Section py={40}>
        <h2 className="section-title">בדקו את העסקאות הטובות ביותר</h2>
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr', gap: 12 }}>
          {DEALS_CAROUSEL.slice(0, 3).map((d, i) => (
            <div key={i} style={{
              borderRadius: 'var(--radius-md)',
              border: '1px solid var(--gray-200)',
              padding: i === 0 ? 28 : 20,
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'space-between',
              minHeight: 160,
              background: i === 0 ? 'var(--cream)' : 'var(--white)',
            }}>
              {d.badge && <span className="badge badge-red" style={{ alignSelf: 'flex-start', marginBottom: 8 }}>{d.badge}</span>}
              <div>
                <div style={{ fontSize: i === 0 ? 20 : 16, fontWeight: 800, color: 'var(--gray-800)', marginBottom: 4 }}>{d.title}</div>
                <div style={{ fontSize: 13, color: 'var(--gray-600)' }}>{d.sub}</div>
              </div>
              {i === 0 && <button className="btn-secondary" style={{ alignSelf: 'flex-start', marginTop: 16, fontSize: 13 }}>לקנייה עכשיו</button>}
            </div>
          ))}
        </div>
      </Section>

      {/* ══════════ EDITORIAL TABS ══════════ */}
      <Section bg="var(--cream)" py={40}>
        <h2 className="section-title">כל מה שצריך לעונת הגינה</h2>
        <div style={{ display: 'flex', gap: 4, marginBottom: 0 }}>
          {EDITORIAL_TABS.map((t, i) => (
            <button key={t.label} onClick={() => setEditTab(i)} style={{
              padding: '8px 18px',
              fontSize: 12,
              fontWeight: 700,
              border: 'none',
              cursor: 'pointer',
              fontFamily: 'var(--font)',
              background: i === editTab ? 'var(--brown)' : 'var(--brown-light)',
              color: i === editTab ? 'var(--gold)' : 'rgba(255,255,255,0.7)',
              borderRadius: i === 0 ? '6px 0 0 0' : i === EDITORIAL_TABS.length - 1 ? '0 6px 0 0' : '0',
            }}>{t.label}</button>
          ))}
        </div>
        <div style={{ background: 'var(--cream-dark)', borderRadius: '0 var(--radius-md) var(--radius-md) var(--radius-md)', padding: 24 }}>
          <div style={{ display: 'grid', gridTemplateColumns: '120px 1fr', gap: 20, alignItems: 'center' }}>
            <div style={{ background: 'var(--gray-200)', height: 100, borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 36 }}>📸</div>
            <div>
              <h3 style={{ fontSize: 16, fontWeight: 800, color: 'var(--brown)', marginBottom: 8 }}>{EDITORIAL_TABS[editTab].title}</h3>
              <p style={{ fontSize: 13, color: 'var(--gray-600)', marginBottom: 14 }}>{EDITORIAL_TABS[editTab].body}</p>
              <button className="btn-secondary" style={{ fontSize: 12, padding: '8px 18px' }}>קרא עוד</button>
            </div>
          </div>
        </div>
      </Section>

      {/* ══════════ FULL WIDTH IMAGE BANNER ══════════ */}
      <Section py={0}>
        <div style={{ background: 'var(--brown)', borderRadius: 'var(--radius-lg)', padding: '32px 40px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24, alignItems: 'center', margin: '32px 0' }}>
          <div>
            <div style={{ fontSize: 20, fontWeight: 900, color: '#fff', lineHeight: 1.4, marginBottom: 8 }}>אתה לא צריך מומחה כדי לשפץ נכון</div>
            <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.75)', marginBottom: 20 }}>מומחי BOB עוזרים לך לתכנן, לבצע ולסיים כל פרויקט.</div>
            <Link href="/tips" className="btn-primary" style={{ display: 'inline-flex' }}>קבל תוכנית ←</Link>
          </div>
          <div style={{ background: 'rgba(255,255,255,0.08)', borderRadius: 12, height: 140, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 48 }}>🏡</div>
        </div>
      </Section>

      {/* ══════════ BRANDS ══════════ */}
      <Section bg="var(--cream)" py={40}>
        <h2 className="section-title">המותגים המובילים תחת קורת גג אחת</h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 10 }}>
          {BRANDS.map(b => (
            <div key={b} style={{
              background: 'var(--white)',
              border: '1px solid var(--gray-200)',
              borderRadius: 'var(--radius-md)',
              padding: '18px 8px',
              textAlign: 'center',
              fontSize: 13,
              fontWeight: 700,
              color: 'var(--gray-800)',
              transition: 'box-shadow 0.15s',
              cursor: 'pointer',
            }}
              onMouseEnter={e => (e.currentTarget.style.boxShadow = 'var(--shadow-md)')}
              onMouseLeave={e => (e.currentTarget.style.boxShadow = 'none')}
            >{b}</div>
          ))}
        </div>
      </Section>

      {/* ══════════ FOOTER ══════════ */}
      <footer style={{ background: 'var(--brown-dark)', color: '#ccc', padding: '40px 0 0', direction: 'rtl' }}>
        <div className="container">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr) 200px', gap: 24, marginBottom: 32 }}>
            {[
              { title: 'דרכי קנייה', items: ['איתור סניף', 'מבצעים', 'מותגים שלנו', 'כרטיסי מתנה', 'אפליקציה'] },
              { title: 'שירות לקוחות', items: ['צור קשר', 'מעקב הזמנה', 'החזרות קלות', 'משלוח ואיסוף', 'אבטחה מקוונת'] },
              { title: 'על BOB', items: ['אודות', 'קריירה', 'תוכנית שותפים', 'ספקים', 'סניפים'] },
              { title: 'משאבים', items: ['טיפים ועצות', 'מבצעים', 'שירותי חנות', 'חדשות', 'שירות בינלאומי'] },
            ].map(col => (
              <div key={col.title}>
                <h4 style={{ color: '#fff', fontSize: 14, fontWeight: 700, marginBottom: 12 }}>{col.title}</h4>
                <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 7 }}>
                  {col.items.map(it => (
                    <li key={it}><Link href="#" style={{ fontSize: 13, color: 'var(--gray-400)', transition: 'color 0.15s' }}
                      onMouseEnter={e => (e.currentTarget.style.color = 'var(--gold-light)')}
                      onMouseLeave={e => (e.currentTarget.style.color = 'var(--gray-400)')}
                    >{it}</Link></li>
                  ))}
                </ul>
              </div>
            ))}

            {/* REWARDS BOX */}
            <div style={{ background: 'var(--red)', borderRadius: 'var(--radius-md)', padding: 20, textAlign: 'center' }}>
              <div style={{ fontSize: 20, fontWeight: 900, color: '#fff', marginBottom: 4 }}>BOB</div>
              <div style={{ fontSize: 14, fontWeight: 900, color: 'var(--gold)', letterSpacing: 2, marginBottom: 16 }}>REWARDS</div>
              <Link href="#" style={{ display: 'block', color: 'var(--gold-light)', fontSize: 12, marginBottom: 6 }}>למד עוד</Link>
              <Link href="#" style={{ display: 'block', color: '#fff', fontSize: 12, fontWeight: 700 }}>הצטרף עכשיו ←</Link>
            </div>
          </div>

          {/* NEWSLETTER */}
          <div style={{ borderTop: '1px solid rgba(255,255,255,0.1)', padding: '24px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <div style={{ fontSize: 14, color: '#fff', fontWeight: 600, marginBottom: 10 }}>💡 קבל הצעות בלעדיות וטיפים מקצועיים</div>
              <div style={{ display: 'flex' }}>
                <input type="email" placeholder="הכנס כתובת אימייל" style={{
                  border: 'none',
                  padding: '9px 16px',
                  fontSize: 13,
                  width: 240,
                  borderRadius: '6px 0 0 6px',
                  fontFamily: 'var(--font)',
                  direction: 'rtl',
                  outline: 'none',
                }} />
                <button style={{
                  background: 'var(--gold)',
                  color: 'var(--brown-dark)',
                  border: 'none',
                  padding: '9px 20px',
                  fontWeight: 700,
                  fontSize: 13,
                  borderRadius: '0 6px 6px 0',
                  cursor: 'pointer',
                  fontFamily: 'var(--font)',
                }}>הצטרף</button>
              </div>
            </div>
            <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.7)' }}>
              🏪 <strong style={{ color: '#fff' }}>פתח סניף BOB</strong> — הכלי העסקי המושלם לצמיחה שלך
            </div>
          </div>

          {/* SOCIAL */}
          <div style={{ borderTop: '1px solid rgba(255,255,255,0.1)', padding: '20px 0', display: 'flex', justifyContent: 'center', gap: 24 }}>
            {['Facebook','Instagram','X','Pinterest','YouTube','TikTok'].map(s => (
              <Link key={s} href="#" style={{ fontSize: 13, color: 'var(--gray-400)', transition: 'color 0.15s' }}
                onMouseEnter={e => (e.currentTarget.style.color = 'var(--gold-light)')}
                onMouseLeave={e => (e.currentTarget.style.color = 'var(--gray-400)')}
              >{s}</Link>
            ))}
          </div>

          {/* COPYRIGHT */}
          <div style={{ borderTop: '1px solid rgba(255,255,255,0.08)', padding: '16px 0', textAlign: 'center' }}>
            <div style={{ display: 'flex', justifyContent: 'center', gap: 20, marginBottom: 10, flexWrap: 'wrap' }}>
              {['תנאי שימוש','מדיניות פרטיות','נגישות','שאלות נפוצות'].map(l => (
                <Link key={l} href="#" style={{ fontSize: 12, color: 'var(--gray-400)' }}>{l}</Link>
              ))}
            </div>
            <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.3)' }}>
              © 2025 בוב חומרי בניין. כל הזכויות שמורות.
            </div>
          </div>
        </div>
      </footer>
    </main>
  );
}
