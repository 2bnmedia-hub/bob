'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useCart } from '@/context/CartContext';

const NAV_LINKS = [
  { label: 'קטגוריות', href: '/categories' },
  { label: 'מבצעים', href: '/sales' },
  { label: 'שירותים', href: '/services' },
  { label: 'פרויקטים וטיפים', href: '/tips' },
];

const CATEGORY_PILLS = [
  { label: 'מבצעי השבוע', href: '/sales', highlight: 'gold' },
  { label: 'מבצעים מיוחדים', href: '/specials', highlight: 'red' },
  { label: 'בניין ושיפוץ', href: '/category/building' },
  { label: 'כלי עבודה', href: '/category/tools' },
  { label: 'חשמל ותאורה', href: '/category/electric' },
  { label: 'צבע וגימור', href: '/category/paint' },
  { label: 'אינסטלציה', href: '/category/plumbing' },
  { label: 'גינה וחוץ', href: '/category/garden' },
  { label: 'דלתות וחלונות', href: '/category/doors' },
  { label: 'ריצוף', href: '/category/flooring' },
  { label: 'בטיחות', href: '/category/safety' },
];

export default function Header() {
  const { items } = useCart();
  const [search, setSearch] = useState('');
  const [menuOpen, setMenuOpen] = useState(false);

  const cartCount = items.reduce((sum, i) => sum + i.quantity, 0);

  return (
    <header style={{ position: 'sticky', top: 0, zIndex: 100, background: '#fff', boxShadow: '0 2px 12px rgba(0,0,0,0.08)' }}>

      {/* ── TOP BAR ── */}
      <div style={{ background: 'var(--brown)', color: 'var(--gold-light)', fontSize: 12, padding: '5px var(--px)', direction: 'rtl' }}>
        <div className="container" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span style={{ fontSize: 11 }}>📍 נתניה — פתוח היום 07:00–20:00</span>
          <div style={{ display: 'flex', gap: 20 }}>
            <Link href="/rewards" style={{ color: 'var(--gold-light)', fontSize: 11 }}>תוכנית נאמנות</Link>
            <Link href="/business" style={{ color: 'var(--gold-light)', fontSize: 11 }}>חשבון עסקי</Link>
            <Link href="/contact" style={{ color: 'var(--gold-light)', fontSize: 11 }}>צור קשר</Link>
          </div>
        </div>
      </div>

      {/* ── MAIN HEADER ── */}
      <div style={{ borderBottom: '1px solid var(--gray-200)', padding: '10px 0' }}>
        <div className="container" style={{ display: 'flex', alignItems: 'center', gap: 20, direction: 'rtl' }}>

          {/* LOGO */}
          <Link href="/" style={{ display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0 }}>
            <div style={{
              background: 'var(--brown)',
              color: 'var(--gold)',
              fontWeight: 900,
              fontSize: 26,
              padding: '6px 16px',
              borderRadius: 8,
              letterSpacing: 2,
              fontFamily: 'var(--font)',
            }}>
              BOB
            </div>
            <div style={{ lineHeight: 1.2 }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--brown)' }}>חומרי בניין</div>
              <div style={{ fontSize: 10, color: 'var(--gray-400)' }}>The Building Place</div>
            </div>
          </Link>

          {/* NAV */}
          <nav style={{ display: 'flex', gap: 6, flexShrink: 0 }}>
            {NAV_LINKS.map(l => (
              <Link key={l.href} href={l.href} style={{
                fontSize: 14,
                fontWeight: 600,
                color: 'var(--brown)',
                padding: '6px 12px',
                borderRadius: 6,
                transition: 'background 0.15s',
              }}
                onMouseEnter={e => (e.currentTarget.style.background = 'var(--cream)')}
                onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
              >
                {l.label} ▾
              </Link>
            ))}
          </nav>

          {/* SEARCH */}
          <div style={{ flex: 1, display: 'flex', margin: '0 8px' }}>
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="חיפוש מוצרים, מותגים, קטגוריות..."
              style={{
                flex: 1,
                border: '2px solid var(--gold)',
                borderRadius: '8px 0 0 8px',
                padding: '9px 16px',
                fontSize: 14,
                outline: 'none',
                fontFamily: 'var(--font)',
                direction: 'rtl',
                background: 'var(--gray-50)',
              }}
            />
            <button style={{
              background: 'var(--gold)',
              color: 'var(--brown-dark)',
              fontWeight: 800,
              fontSize: 16,
              padding: '9px 20px',
              borderRadius: '0 8px 8px 0',
              border: '2px solid var(--gold)',
              borderRight: 'none',
            }}>
              🔍
            </button>
          </div>

          {/* USER + CART */}
          <div style={{ display: 'flex', gap: 14, alignItems: 'center', flexShrink: 0 }}>
            <Link href="/account" style={{ textAlign: 'center', color: 'var(--brown)', fontSize: 12, fontWeight: 600 }}>
              <div style={{ fontSize: 20 }}>👤</div>
              <div>כניסה</div>
            </Link>
            <Link href="/cart" style={{ position: 'relative', textAlign: 'center', color: 'var(--brown)', fontSize: 12, fontWeight: 600 }}>
              <div style={{ fontSize: 20 }}>🛒</div>
              <div>סל קניות</div>
              {cartCount > 0 && (
                <span style={{
                  position: 'absolute',
                  top: -4,
                  left: -4,
                  background: 'var(--red)',
                  color: '#fff',
                  fontSize: 10,
                  fontWeight: 700,
                  width: 18,
                  height: 18,
                  borderRadius: '50%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}>
                  {cartCount}
                </span>
              )}
            </Link>
          </div>
        </div>
      </div>

      {/* ── CATEGORY PILLS ── */}
      <div style={{
        background: 'var(--cream)',
        borderBottom: '1px solid var(--cream-dark)',
        overflowX: 'auto',
        scrollbarWidth: 'none',
      }}>
        <div className="container" style={{
          display: 'flex',
          gap: 8,
          padding: '8px var(--px)',
          direction: 'rtl',
          whiteSpace: 'nowrap',
        }}>
          {CATEGORY_PILLS.map(p => (
            <Link key={p.href} href={p.href} style={{
              display: 'inline-block',
              padding: '5px 14px',
              borderRadius: 20,
              fontSize: 12,
              fontWeight: 600,
              border: p.highlight === 'gold'
                ? '1.5px solid var(--gold)'
                : p.highlight === 'red'
                  ? '1.5px solid var(--red)'
                  : '1.5px solid var(--gray-200)',
              background: p.highlight === 'gold'
                ? 'var(--gold)'
                : p.highlight === 'red'
                  ? 'var(--red)'
                  : 'var(--white)',
              color: p.highlight === 'gold'
                ? 'var(--brown-dark)'
                : p.highlight === 'red'
                  ? '#fff'
                  : 'var(--gray-600)',
              transition: 'all 0.15s',
              flexShrink: 0,
            }}>
              {p.label}
            </Link>
          ))}
        </div>
      </div>
    </header>
  );
}
